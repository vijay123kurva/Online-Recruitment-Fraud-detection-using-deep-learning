from django.db.models import Count
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404

import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import VotingClassifier
# Create your views here.
from Remote_User.models import ClientRegister_Model,online_recruitment_fraud_detection,detection_ratio,detection_accuracy

def login(request):


    if request.method == "POST" and 'submit1' in request.POST:

        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            enter = ClientRegister_Model.objects.get(username=username,password=password)
            request.session["userid"] = enter.id

            return redirect('ViewYourProfile')
        except:
            pass

    return render(request,'RUser/login.html')

def index(request):
    return render(request, 'RUser/index.html')

def Add_DataSet_Details(request):

    return render(request, 'RUser/Add_DataSet_Details.html', {"excel_data": ''})


def Register1(request):

    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phoneno = request.POST.get('phoneno')
        country = request.POST.get('country')
        state = request.POST.get('state')
        city = request.POST.get('city')
        address = request.POST.get('address')
        gender = request.POST.get('gender')
        ClientRegister_Model.objects.create(username=username, email=email, password=password, phoneno=phoneno,
                                            country=country, state=state, city=city,address=address,gender=gender)

        obj = "Registered Successfully"
        return render(request, 'RUser/Register1.html',{'object':obj})
    else:
        return render(request,'RUser/Register1.html')

def ViewYourProfile(request):
    userid = request.session['userid']
    obj = ClientRegister_Model.objects.get(id= userid)
    return render(request,'RUser/ViewYourProfile.html',{'object':obj})


def Predict_Online_Recruitment_Fraud_Detection(request):
    if request.method == "POST":

        if request.method == "POST":


            Fid= request.POST.get('Fid')
            jobpost= request.POST.get('jobpost')
            Title= request.POST.get('Title')
            Company= request.POST.get('Company')
            AnnouncementCode= request.POST.get('AnnouncementCode')
            Term= request.POST.get('Term')
            Eligibility= request.POST.get('Eligibility')
            Duration= request.POST.get('Duration')
            Location= request.POST.get('Location')
            JobDescription= request.POST.get('JobDescription')
            JobRequirment= request.POST.get('JobRequirment')
            RequiredQual= request.POST.get('RequiredQual')
            Salary= request.POST.get('Salary')
            ApplicationP= request.POST.get('ApplicationP')
            OpeningDate= request.POST.get('OpeningDate')
            Deadline= request.POST.get('Deadline')
            AboutC= request.POST.get('AboutC')
            IT= request.POST.get('IT')

        df = pd.read_csv('Datasets.csv')

        def apply_response(label):
            if (label == 0):
                return 0  # No Fraud Found
            elif (label == 1):
                return 1  # Fraud Found

        df['results'] = df['Label'].apply(apply_response)

        cv = CountVectorizer()
        X = df['Fid'].apply(str)
        y = df['results']

        print("Fid")
        print(X)
        print("Results")
        print(y)

        X = cv.fit_transform(X)

        models = []
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20)
        X_train.shape, X_test.shape, y_train.shape

        print("Recurrent Neural Network-RNN")
        from sklearn.neural_network import MLPClassifier
        mlpc = MLPClassifier().fit(X_train, y_train)
        y_pred = mlpc.predict(X_test)
        testscore_mlpc = accuracy_score(y_test, y_pred)
        accuracy_score(y_test, y_pred)
        print(accuracy_score(y_test, y_pred))
        print(accuracy_score(y_test, y_pred) * 100)
        print("CLASSIFICATION REPORT")
        print(classification_report(y_test, y_pred))
        print("CONFUSION MATRIX")
        print(confusion_matrix(y_test, y_pred))
        models.append(('MLPClassifier', mlpc))

        print("Logistic Regression")

        from sklearn.linear_model import LogisticRegression
        reg = LogisticRegression(random_state=0, solver='lbfgs').fit(X_train, y_train)
        y_pred = reg.predict(X_test)
        print("ACCURACY")
        print(accuracy_score(y_test, y_pred) * 100)
        print("CLASSIFICATION REPORT")
        print(classification_report(y_test, y_pred))
        print("CONFUSION MATRIX")
        print(confusion_matrix(y_test, y_pred))
        models.append(('logistic', reg))

        print("LightGBM")

        from sklearn.ensemble import GradientBoostingClassifier
        clf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=1, random_state=0).fit(
            X_train,
            y_train)
        clfpredict = clf.predict(X_test)
        print("ACCURACY")
        print(accuracy_score(y_test, clfpredict) * 100)
        print("CLASSIFICATION REPORT")
        print(classification_report(y_test, clfpredict))
        print("CONFUSION MATRIX")
        print(confusion_matrix(y_test, clfpredict))
        models.append(('GradientBoostingClassifier', clf))


        classifier = VotingClassifier(models)
        classifier.fit(X_train, y_train)
        y_pred = classifier.predict(X_test)

        Fid1 = [Fid]
        vector1 = cv.transform(Fid1).toarray()
        predict_text = classifier.predict(vector1)

        pred = str(predict_text).replace("[", "")
        pred1 = pred.replace("]", "")

        prediction = int(pred1)

        if (prediction == 0):
            val = 'Fraud Not Found'
        elif (prediction == 1):
            val = 'Fraud Found'

        print(val)
        print(pred1)

        online_recruitment_fraud_detection.objects.create(
        Fid=Fid,
        jobpost=jobpost,
        Title=Title,
        Company=Company,
        AnnouncementCode=AnnouncementCode,
        Term=Term,
        Eligibility=Eligibility,
        Duration=Duration,
        Location=Location,
        JobDescription=JobDescription,
        JobRequirment=JobRequirment,
        RequiredQual=RequiredQual,
        Salary=Salary,
        ApplicationP=ApplicationP,
        OpeningDate=OpeningDate,
        Deadline=Deadline,
        AboutC=AboutC,
        IT=IT,
        Prediction=val)

        return render(request, 'RUser/Predict_Online_Recruitment_Fraud_Detection.html',{'objs': val})
    return render(request, 'RUser/Predict_Online_Recruitment_Fraud_Detection.html')



