from django.db import models

# Create your models here.
from django.db.models import CASCADE


class ClientRegister_Model(models.Model):
    username = models.CharField(max_length=30)
    email = models.EmailField(max_length=30)
    password = models.CharField(max_length=10)
    phoneno = models.CharField(max_length=10)
    country = models.CharField(max_length=30)
    state = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    gender= models.CharField(max_length=30)
    address= models.CharField(max_length=30)


class online_recruitment_fraud_detection(models.Model):

    Fid= models.CharField(max_length=300)
    jobpost= models.CharField(max_length=300)
    Title= models.CharField(max_length=300)
    Company= models.CharField(max_length=300)
    AnnouncementCode= models.CharField(max_length=300)
    Term= models.CharField(max_length=300)
    Eligibility= models.CharField(max_length=300)
    Duration= models.CharField(max_length=300)
    Location= models.CharField(max_length=300)
    JobDescription= models.CharField(max_length=3000)
    JobRequirment= models.CharField(max_length=300)
    RequiredQual= models.CharField(max_length=300)
    Salary= models.CharField(max_length=300)
    ApplicationP= models.CharField(max_length=300)
    OpeningDate= models.CharField(max_length=300)
    Deadline= models.CharField(max_length=300)
    AboutC= models.CharField(max_length=300)
    IT= models.CharField(max_length=300)
    Prediction= models.CharField(max_length=300)


class detection_accuracy(models.Model):

    names = models.CharField(max_length=300)
    ratio = models.CharField(max_length=300)

class detection_ratio(models.Model):

    names = models.CharField(max_length=300)
    ratio = models.CharField(max_length=300)



